import enjarify.main

enjarify.main.main()
